print("hello from python on ubuntu on windows!")
